<?php return array (
  'club-members' => 'App\\Http\\Livewire\\ClubMembers',
  'clubs-table' => 'App\\Http\\Livewire\\ClubsTable',
  'compliance-report' => 'App\\Http\\Livewire\\ComplianceReport',
  'members-table' => 'App\\Http\\Livewire\\MembersTable',
  'user-view' => 'App\\Http\\Livewire\\UserView',
);