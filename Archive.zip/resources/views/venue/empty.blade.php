<td colspan="3">
    <h4 class="text-xl text-gray-400 my-8 text-center">No venue assigned to the club yet.</h4>
</td>
