<div class="inline-block">
    <a {{ $attributes }}> {{ $slot }}</a>
</div>
