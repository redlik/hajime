<td colspan="8">
    <h4 class="text-xl text-gray-400 my-8 text-center">No records available at this moment.</h4>
</td>
