@extends('layouts.app')

@section('content')
    <main class="sm:container sm:mx-auto sm:mt-10">
        <div class="w-full sm:px-6">

            <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">

                <header class="font-semibold bg-gray-600 text-gray-100 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                    <i class="fas fa-sticky-note mr-2 text-gray-300"></i> Edit note
                </header>

                <div class="w-full p-6">
                    <div class="w-full mb-4">
                        <a href="{{ route('member.show', $note->member_id) }}#notes" class="blue-pillow"><< Back to
                            Member page</a>
                    </div>
                    @if(Session::has('message'))
                        <p class="bg-green-100 text-green-700 p-6 rounded mb-4">{{ Session::get('message') }}</p>
                    @endif
                    @if ($errors->any())
                        <div class="alert alert-danger" role="alert">
                            <ul id="errors list-unstyled">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <form method="POST" action="{{ action('App\Http\Controllers\MembernoteController@update', ['membernote' => $note->id]) }}"
                          role="form">
                        @csrf
                        <input name="_method" type="hidden" value="PUT">
                        <div class="w-full border-2 border-gray-300 rounded-xl p-8 mb-4">
                            <div class="mb-4">
                                <label class="inline-block w-24 text-grey-darker text-sm font-bold mb-2" for="title">
                                    Title
                                </label>
                                <input
                                    class="shadow border-gray-300 rounded w-full md:w-1/2 py-2 px-3 text-grey-darker"
                                    id="title" name="title" type="text" placeholder="Title" required value="{{ $note->title }}">
                            </div>
                            <div class="mb-4 flex items-start">
                                <label class="inline-block w-24 text-grey-darker text-sm font-bold mb-2" for="body">
                                    Body
                                </label>
                                <textarea id="body" name="body" rows="20" cols="50"
                                          class="shadow border-gray-300 rounded w-full md:w-1/2 py-2 px-3 text-grey-darker">{{ $note->body }}</textarea>
                            </div>
                            <div class="mt-6">
                                <input type="submit" value="Save changes" class="button-judo ml-24">
                            </div>
                        </div>

                    </form>
                </div>

            </section>
        </div>
    </main>
@endsection
