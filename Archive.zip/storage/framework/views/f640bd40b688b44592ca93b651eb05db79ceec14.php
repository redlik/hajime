<?php $__env->startSection('content'); ?>
    <main class="sm:container sm:mx-auto sm:mt-10">
        <div class="w-full sm:px-6">
            <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">

                <header class="font-semibold text-xl bg-gray-600 text-gray-100 py-4 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                    User accounts
                </header>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-view')->html();
} elseif ($_instance->childHasBeenRendered('eDRebgN')) {
    $componentId = $_instance->getRenderedChildComponentId('eDRebgN');
    $componentTag = $_instance->getRenderedChildComponentTagName('eDRebgN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eDRebgN');
} else {
    $response = \Livewire\Livewire::mount('user-view');
    $html = $response->html();
    $_instance->logRenderedChild('eDRebgN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rafal/Sites/hajime/resources/views/club-access/users-list.blade.php ENDPATH**/ ?>