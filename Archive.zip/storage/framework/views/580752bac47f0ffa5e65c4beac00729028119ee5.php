<td colspan="6">
    <h4 class="text-xl text-gray-400 my-5 text-center">No coaches assigned to the club yet.</h4>
</td>
<?php /**PATH /Users/rafal/Sites/hajime/resources/views/coach/empty.blade.php ENDPATH**/ ?>