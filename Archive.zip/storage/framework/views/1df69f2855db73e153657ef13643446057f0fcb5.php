<tr>
    <td class="px-5 py-5 border-b border-gray-200 text-sm">
        <div class="flex items-center">
            <div class="ml-3">
                <p class="text-gray-900 whitespace-no-wrap font-bold">
                    <a href="<?php echo e(asset('/storage/attachments/'.$document->link)); ?>"
                       target="_blank" title="<?php echo e($document->link); ?>">
                        <?php echo e($document->title); ?>

                    </a>
                </p>
            </div>
        </div>
    </td>
    <td class="px-5 py-5 border-b border-gray-200 text-sm">
        <a href="<?php echo e(asset('/storage/attachments/'.$document->link)); ?>"
           target="_blank" title="<?php echo e($document->link); ?>">
            <i class="fas fa-file-pdf text-2xl text-red-700 mr-3"></i><span
                class="text-gray-500"><?php echo e($document->link); ?></span>
        </a>
    </td>
    <td class="px-5 py-5 border-b border-gray-200 text-sm">
        <?php if($document->author): ?>
            <?php echo e($document->hasAuthor->name); ?>

        <?php endif; ?>
    </td>
    <td class="px-5 py-5 border-b border-gray-200 text-sm">
        <?php echo e($document->created_at->format('d-m-Y')); ?>

    </td>
    <td class="px-5 py-6 border-b border-gray-200 text-sm flex flex-wrap
                                            justify-center">
        <form action="<?php echo e(route('clubdoc.destroy', $document->id)); ?>"
              method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" value="DELETE"/>
            <button type="submit"
                    class="text-red-600 hover:text-red-300 whitespace-no-wrap"
                    onclick="return confirm('Do you want to delete the record completely?')"
                    title="Delete document">
                <i class="far fa-trash-alt"></i></button>
        </form>
    </td>
</tr>
<?php /**PATH /Users/rafal/Sites/hajime/resources/views/clubs/document-list.blade.php ENDPATH**/ ?>