<div class="container">
    <div class="w-full">
        <div class="flex flex-wrap content-center justify-between mt-4">
            <div class="w-full md:w-1/2">
                <input type="search" wire:model.debounce.500ms="searchQuery" class="shadow border-gray-300 rounded
                w-full py-2 px-3 text-grey-darker mt-4" placeholder="Filter by name"></div>
            <div class="">
                <?php echo e($clubs->links()); ?></div>
        </div>


        <table class="min-w-full table leading-normal mt-8">
            <thead>
                <tr>
                    <th
                        class="px-5 py-3 rounded-l bg-gray-600 text-left text-xs
                        font-semibold
                        text-gray-100 uppercase tracking-wider">
                        Club name
                    </th>
                    <th
                        class="px-5 py-3 bg-gray-600 text-left text-xs font-semibold
                        text-gray-100 uppercase tracking-wider hidden md:block">
                        Location
                    </th>
                    <th
                        class="px-5 py-3 bg-gray-600 text-center text-xs font-semibold
                        text-gray-100 uppercase tracking-wider">
                        Members (Active)
                    </th>
                    <th
                        class="px-5 py-3 bg-gray-600 text-center text-xs font-semibold
                        text-gray-100 uppercase tracking-wider">
                        Status
                    </th>
                    <th
                        class="px-5 py-3 rounded-r bg-gray-600 text-left text-xs
                        font-semibold
                        text-gray-100 uppercase tracking-wider">
                        Operations
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-200">
                    <td class="px-5 py-5 border-b border-gray-200 text-sm">
                        <div class="flex items-center">
                            <div class="ml-3">
                                <p class="text-gray-900 whitespace-no-wrap font-bold">
                                    <a href="<?php echo e(route('clubs.show', $club)); ?>" class="hover:text-cool-gray-400" title="View club page"><?php echo e($club->name); ?></a>
                                </p>
                            </div>
                        </div>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 text-sm hidden md:block">
                        <p class="text-gray-900 whitespace-no-wrap"><?php echo e($club->address1); ?>, <?php echo e($club->city); ?>

                        </p>
                    </td>
                    <td class="py-5 border-b border-gray-200 text-sm">
                        <p class="text-gray-900 whitespace-no-wrap text-center">
                            <?php echo e($club->activeMembersCount()); ?>

                        </p>
                    </td>
                    <td class="py-5 border-b border-gray-200 text-sm">
                        <p class="text-gray-900 whitespace-no-wrap text-center">
                            <?php if($club->status == "Active"): ?>
                                <span class="green-pillow">Active</span>
                            <?php else: ?>
                                <span class="red-pillow">Inactive</span>
                            <?php endif; ?>
                        </p>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 text-sm">
                        <p class="text-gray-900 whitespace-no-wrap">
                            <a href="<?php echo e(route('clubs.show', $club)); ?>" class="text-blue-600 font-bold hover:text-blue-300" title="View club page"><i class="far fa-eye"></i></a>
                            <a href="<?php echo e(route('clubs.edit', $club)); ?>" class="text-green-600 font-bold ml-3" title="Edit club details"><i class="far fa-edit"></i></a>
                        </p>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-4">
            <?php echo e($clubs->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH /Users/rafal/Sites/hajime/resources/views/livewire/clubs-table.blade.php ENDPATH**/ ?>