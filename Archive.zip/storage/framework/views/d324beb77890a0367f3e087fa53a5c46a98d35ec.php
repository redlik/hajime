<?php $__env->startSection('content'); ?>
<main class="sm:container sm:mx-auto sm:max-w-lg sm:mt-10">
    <div class="flex">
        <div class="w-full">
            <section class="flex flex-col break-words bg-white sm:border-1 sm:rounded-md sm:shadow-sm sm:shadow-lg">

                <header class="font-semibold bg-gray-200 text-gray-700 py-5 px-6 sm:py-6 sm:px-8 sm:rounded-t-md">
                    <?php echo e(__('Authentication')); ?>

                </header>

                <form class="w-full px-6 pb-8 space-y-6 sm:px-10 sm:space-y-8" method="POST" action="/two-factor-challenge">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-wrap">
                        <label for="email" class="block text-gray-700 text-sm font-bold mb-2 sm:mb-4">
                            <?php echo e(__('Authentication code')); ?>:
                        </label>

                        <input id="code" type="text"
                            class="border-gray-300 rounded shadow-sm focus:shadow-lg w-full" name="code"
                             required autofocus autocomplete="false">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs italic mt-4">
                            <?php echo e($message); ?>

                        </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="flex flex-wrap my-12">
                        <button type="submit"
                        class="w-full select-none font-bold whitespace-no-wrap p-3 rounded-lg text-base leading-normal no-underline text-gray-100 bg-judo-green hover:bg-green-700 sm:py-4">
                            <?php echo e(__('Authenticate')); ?>

                        </button>
                    </div>
                </form>
            </section>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rafal/Sites/hajime/resources/views/auth/two-factor-challenge.blade.php ENDPATH**/ ?>