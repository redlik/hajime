<div class="container">

    <div class="w-full">
        <div class="w-full flex flex-wrap items-center justify-between my-4 p-3 rounded bg-gray-100">
            <div class="">
                <input type="search" wire:model.debounce.500ms="searchQuery"
                       class="shadow border-gray-300 rounded w-full py-2 px-3 text-grey-darker"
                       placeholder="Filter by name, number or eircode">
            </div>
            <div class="">
                <label for="sort">Sort by:</label>
                <select wire:model="sortby" name="sort" id="sort" class="shadow border-gray-300 rounded w-48
                text-grey-darker ml-2">
                    <option value="last_name" selected>Last Name</option>
                    <option value="number">Memership No</option>
                </select>
            </div>
            <div class="">
                <input type="checkbox" wire:model="active" id="showActive" name="showActive" value="1" checked
                       class="rounded border-judo-300
                                text-judo-600 shadow-sm focus:border-judo-300 focus:ring focus:ring-judo-200
                                focus:ring-opacity-50">
                <label for="showActive">Show active members only</label>
            </div>
            <div class="">
                <a href="<?php echo e(route('club.checkMemberships', ['club' => $club_id])); ?>" class="button-judo">
                    <i class="fas fa-sync-alt mr-2"></i>
                    Check memberships</a>
            </div>
        </div>
        <div class="w-full">
            <?php echo e($active); ?>

        </div>
        <div class="w-full">
            <div class="w-full">
                <?php if(Session::has('message')): ?>
                    <p class="bg-green-100 text-green-700 p-6 rounded mb-4"><?php echo e(Session::get('message')); ?></p>
                <?php endif; ?>
            </div>
            <div class="w-full my-4">
                <?php echo e($members->links()); ?></div>
        </div>
        <table class="min-w-full table-auto leading-normal">
            <thead>
                <tr>
                    <th
                        class="px-5 py-3 rounded-l bg-gray-600 text-left text-xs font-semibold
                        text-gray-100
                        uppercase tracking-wider shadow-lg">
                        Memb. No
                    </th>
                    <th
                        class="px-5 py-3 bg-gray-600 text-left text-xs font-semibold
                        text-gray-100
                        uppercase tracking-wider shadow-lg">
                        Name
                    </th>
                    <th
                        class="px-5 py-3 bg-gray-600 text-left text-xs font-semibold
                        text-gray-100
                        uppercase tracking-wider hidden md:block shadow-lg">
                        Age
                    </th>
                    <th
                        class="px-5 py-3 bg-gray-600 text-left text-xs font-semibold
                        text-gray-100
                        uppercase tracking-wider shadow-lg">
                        Status
                    </th>
                    <th
                        class="px-5 py-3 bg-gray-600 text-left text-xs font-semibold
                        text-gray-100
                        uppercase tracking-wider shadow-lg">
                        Membership Type
                    </th>
                    <th
                        class="px-5 py-3 bg-gray-600 text-left text-xs font-semibold
                        text-gray-100
                        uppercase tracking-wider shadow-lg">
                        Grade
                    </th>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                    <th
                        class="px-5 py-3 rounded-r bg-gray-600 text-center text-xs font-semibold text-gray-100
                        uppercase
                        tracking-wider shadow-lg">
                        Actions
                    </th>
                    <?php endif; ?>
                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'manager')): ?>
                    <th
                        class="px-5 py-3 rounded-r bg-gray-600 text-center text-xs font-semibold text-gray-100
                        uppercase
                        tracking-wider shadow-lg">
                    </th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                    <td class="px-5 py-5 border-b border-gray-200 text-sm hidden md:block">
                        <p class="text-gray-900 whitespace-no-wrap"><?php echo e($member->number); ?>

                    </td>
                    <td class="py-5 border-b border-gray-200 text-sm">
                        <div class="flex items-center">
                            <div class="ml-3">
                                <p class="text-gray-900 whitespace-no-wrap font-bold">
                                <a href="<?php echo e(route('member.show', $member)); ?>" class="hover:text-cool-gray-400" title="View club page"><?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></a>
                                </p>
                            </div>
                        </div>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 text-sm hidden md:block">
                        <p class="text-gray-900 whitespace-no-wrap"><?php echo e($member->age); ?> years
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 text-sm">
                        <?php if($member->active == true): ?>
                            <span class="green-pillow">Active</span>
                            <?php else: ?>
                            <span class="red-pillow">Inactive</span>
                            <?php endif; ?>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 text-sm">
                        <?php if($member->membership()->exists()): ?>
                        <p class="text-gray-900"><?php echo e($member->membership->last()->membership_type); ?></p>
                        <?php endif; ?>
                    </td>
                    <td class="px-5 py-5 border-b border-gray-200 text-sm">
                        <?php if($member->grade()->exists()): ?>
                        <p class="text-gray-900"><?php echo e($member->grade->last()->grade_level); ?></p>
                        <?php endif; ?>
                    </td>

                    <td class="px-5 py-5 border-b border-gray-200 text-sm">
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                        <p class="text-gray-900 whitespace-no-wrap">
                            <a href="<?php echo e(route('member.show', $member)); ?>" class="text-blue-600 font-bold
                            hover:text-blue-300" title="View member details"><i class="far fa-eye"></i></a>
                            <a href="<?php echo e(route('member.edit', $member)); ?>" class="text-green-600 font-bold ml-3"
                               title="Edit member details"><i class="far fa-edit"></i></a>
                            <a href="<?php echo e(route('member.duplicate.existing', $member->id)); ?>" class="text-pink-600
                            font-bold
                            hover:text-pink-300 ml-3" title="Clone existing member"><i class="far fa-clone"></i></a>
                        </p>
                        <?php endif; ?>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7">
                            <h4 class="text-xl text-gray-400 my-5 text-center">No member with active
                                membership registered right now.</h4>
                        </td>
                    </tr>
                    <?php endif; ?>
            </tbody>
        </table>

    </div>
</div>
<?php /**PATH /Users/rafal/Sites/hajime/resources/views/livewire/club-members.blade.php ENDPATH**/ ?>