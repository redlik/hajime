<div class="inline-block">
    <a <?php echo e($attributes); ?>> <?php echo e($slot); ?></a>
</div>
<?php /**PATH /Users/rafal/Sites/hajime/resources/views/components/button.blade.php ENDPATH**/ ?>