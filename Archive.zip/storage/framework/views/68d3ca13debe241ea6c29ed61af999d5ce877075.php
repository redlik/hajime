<?php $__env->startSection('content'); ?>
    <main class="w-full flex" style="height: calc(100vh - 48px);">
        <div class="hidden md:block w-1/2 h-full">
            <img src="<?php echo e(asset('images/registration-bg.jpg')); ?>" class="h-full object-cover" alt="">
        </div>
        <div class="w-full lg:w-1/2 flex flex-col bg-white h-full justify-center">

            <?php if(session('status')): ?>
                <div
                    class="text-sm border border-t-8 rounded text-green-700 border-green-600 bg-green-100 px-3 py-4 mb-4"
                    role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <section class="flex flex-col px-2 md:px-12">

                    <header class="font-semibold text-judo-700 text-2xl py-5 px-6 sm:py-6 text-center">
                        <?php echo e(__('Activate new club access account')); ?>

                    </header>

                    <form class="w-full px-6 bg-gray-100 rounded shadown-sm space-y-4 sm:px-10 sm:space-y-8" method="POST"
                          action="<?php echo e(route('user.account-activated')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                        <div class="text-gray-600 text-sm">
                            You are activating the account for email: <?php echo e($user->email); ?> which will access club: <?php echo e($user->club_manager->name); ?>

                        </div>

                        <div class="flex flex-wrap">
                            <label for="name" class="block text-gray-700 text-sm font-bold mb-2 sm:mb-4">
                                <?php echo e(__('Name')); ?>:
                            </label>

                            <input id="name" type="text" class="border-gray-300 rounded shadow-sm focus:shadow-lg w-full <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs italic mt-4">
                                <?php echo e($message); ?>

                            </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="flex flex-wrap">
                            <label for="password" class="block text-gray-700 text-sm font-bold mb-2 sm:mb-4">
                                <?php echo e(__('Password')); ?>:
                            </label>

                            <input id="password" type="password"
                                   class="border-gray-300 rounded shadow-sm focus:shadow-lg w-full <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                   required autocomplete="new-password">

                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs italic mt-4">
                                <?php echo e($message); ?>

                            </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="flex flex-wrap">
                            <label for="password-confirm" class="block text-gray-700 text-sm font-bold mb-2 sm:mb-4">
                                <?php echo e(__('Confirm Password')); ?>:
                            </label>

                            <input id="password-confirm" type="password" class="border-gray-300 rounded shadow-sm focus:shadow-lg w-full"
                                   name="password_confirmation" required autocomplete="new-password">
                        </div>

                        <div class="flex flex-wrap">
                            <button type="submit"
                                    class="w-full select-none font-bold whitespace-no-wrap p-3 rounded-lg text-base leading-normal no-underline text-gray-100 bg-judo-500 hover:bg-judo-600 sm:py-4">
                                <?php echo e(__('Activate account')); ?>

                            </button>

                            <p class="w-full text-xs text-center text-gray-700 my-6 sm:text-sm sm:my-8">
                                <?php echo e(__('Already have an account?')); ?>

                                <a class="text-judo-500 hover:text-judo-700 no-underline hover:underline" href="<?php echo e(route('login')); ?>">
                                    <?php echo e(__('Login')); ?>

                                </a>
                            </p>
                        </div>
                    </form>

                </section>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rafal/Sites/hajime/resources/views/club-access/registration.blade.php ENDPATH**/ ?>