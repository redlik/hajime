<tr>
    <td class="px-5 py-5 border-b border-gray-200 text-sm">
        <div class="flex items-center">
            <div class="">
                <p class="text-gray-900 whitespace-no-wrap font-bold">
                    <?php echo e($venue->name); ?>

                    <br/>
                    <span class="text-sm text-gray-600 font-medium">
                                                            <?php echo e($venue->address1); ?>

                        <?php echo e($venue->address2); ?>

                        <?php echo e($venue->city); ?>

                        <?php echo e(ucfirst ($venue->county)); ?>

                        <?php echo e(strtoupper($venue->eircode)); ?>

                                                        </span>
                </p>
            </div>
        </div>
    </td>
    <td class="px-5 py-5 border-b border-gray-200 text-sm">
        <div class="flex items-center">
            <div>
                <p class="text-gray-900 whitespace-no-wrap font-bold"><?php echo e($venue->contact); ?>

                    <br><span
                        class="font-bold text-gray-500">t:</span><?php echo e($venue->phone); ?>

                </p>
            </div>
        </div>
    </td>
    <td class="px-8 py-8 border-b border-gray-200 text-sm flex flex-wrap h-full">
        <a href="<?php echo e(route('venue.edit', $venue->id)); ?>"
           class="text-green-600 font-bold ml-3" title="Edit venue"><i
                class="far fa-edit"></i></a>
        <form action="<?php echo e(route('venue.destroy', $venue->id)); ?>"
              method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" value="DELETE"/>
            <button type="submit"
                    class="text-red-600 hover:text-red-300 whitespace-no-wrap ml-3"
                    onclick="return confirm('Do you want to delete the venue ' +
                                                         'completely?')">
                <i class="far fa-trash-alt"></i></button>
        </form>
    </td>
</tr>
<?php /**PATH /Users/rafal/Sites/hajime/resources/views/venue/venue-list.blade.php ENDPATH**/ ?>